cite about-plugin
about-plugin 'Install and Run Python Applications in Isolated Environments'

command -v pipx &> /dev/null && pipx ensurepath

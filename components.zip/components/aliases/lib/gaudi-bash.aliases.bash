cite about-alias
about-alias 'Aliases for the gaudi-bash command (these aliases are automatically included with the "general" aliases)'

# Common misspellings of gaudi-bash
alias gudi-bash='gaudi-bash'
alias g-udi-bash='gaudi-bash'
alias gadi-bash='gaudi-bash'
alias guadi-bash='gaudi-bash'

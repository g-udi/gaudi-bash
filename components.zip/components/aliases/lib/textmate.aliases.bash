cite about-alias
about-alias 'textmate aliases'

case $OSTYPE in
  darwin*)
    alias e='mate . &'
    alias et='mate app config db lib public script test spec config.ru Gemfile Rakefile README &'
    ;;
esac

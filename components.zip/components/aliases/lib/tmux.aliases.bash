cite about-alias
about-alias 'tmux terminal multiplexer aliases'

alias txl='tmux ls'
alias txn='tmux new -s'
alias txa='tmux a -t'

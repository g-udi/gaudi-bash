cite about-alias
about-alias 'common git-svn abbreviations'

alias gsr='git svn rebase'
alias gsc='git svn dcommit'
alias gsi='git svn info'



# Bosco completion
eval "$(bosco --completion=bash)"

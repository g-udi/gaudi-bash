cite about-completion
about-completion 'install and run python applications in isolated environments'

# Enable pipx completions
eval "$(register-python-argcomplete pipx)"

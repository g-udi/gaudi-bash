_command_exists oc && source <(oc completion bash)
